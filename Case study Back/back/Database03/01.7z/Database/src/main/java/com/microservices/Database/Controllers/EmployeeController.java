package com.microservices.Database.Controllers;

import java.util.List;
import java.util.Optional;

//import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.microservices.Database.Model.Employee;
import com.microservices.Database.Model.Rooms;
import com.microservices.Database.Repository.EmployeeRepo;
import com.microservices.Database.Services.EmployeeServiceimpl;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeServiceimpl obj;
	//private EmployeeRepo employeeRepo;
	
	@PostMapping(value="/addEmployee")
	public Employee addEmployee(@RequestBody Employee employee) {
		return obj.addEmployee(employee);
	}
	
	@GetMapping("/findAllEmployee")
	public List<Employee> findAllEmployee() {
		return obj.findAllEmployee();
	}
	@GetMapping("/findEmployee/{id}")
	public Optional<Employee> findEmployee(@PathVariable String id) {
		return obj.findEmployeeById(id);
	}
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable String id) {
		obj.deleteEmployeeById(id);
		return "Employee deleted with id : " + id;
	}

	@PutMapping("/updateEmployee")  
	public Employee update(@RequestBody Employee employee)   
	{  
	obj.saveOrUpdate(employee);  
	return employee;  
	} 

}