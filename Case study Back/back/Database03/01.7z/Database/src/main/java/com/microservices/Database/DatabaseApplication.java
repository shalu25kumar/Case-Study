package com.microservices.Database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.microservices.Database.Services.EmployeeServiceimpl;

import com.microservices.Database.Services.Roomserviceimpl;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableEurekaClient
public class DatabaseApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DatabaseApplication.class, args);
	}


	
	@Bean
	public Roomserviceimpl roomserviceimpl() {
		return new Roomserviceimpl();
	}
	@Bean
	public EmployeeServiceimpl employeeserviceimpl() {
		return new EmployeeServiceimpl();
	}
}
