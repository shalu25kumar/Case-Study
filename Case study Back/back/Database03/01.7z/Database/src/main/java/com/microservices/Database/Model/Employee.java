package com.microservices.Database.Model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Employee")
public class Employee {
	
	
	@Id
	private String id;
	private String name;
	private int    age;
	private char   gender;
	private String designation;
	private String phoneno;
	private String address;
	private int    salary;
	private Date   d_o_j;
	
	public Employee () {
	
	}
	
	
	
	public Employee(String id, String name, int age, char gender, String designation, String phoneno, String address,
			int salary, Date d_o_j) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.designation = designation;
		this.phoneno = phoneno;
		this.address = address;
		this.salary = salary;
		this.d_o_j=  d_o_j;
		
		

	}

	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public char getGender() {
		return gender;
	}



	public void setGender(char gender) {
		this.gender = gender;
	}



	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public String getPhoneno() {
		return phoneno;
	}



	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public int getSalary() {
		return salary;
	}



	public void setSalary(int salary) {
		this.salary = salary;
	}



	public Date getD_o_j() {
		return d_o_j;
	}



	public void setD_o_j(Date d_o_j) {
		this.d_o_j = d_o_j;
	}



	@Override
	public String toString() {
		return "Employee [Id=" + id + ", Name=" + name + ", Age=" + age + ", Gender=" + gender + ", Designation="
				+ designation + ", Phoneno=" + phoneno + ", Address=" + address + ", Salary=" + salary + ", D_o_j=" + d_o_j +"]";
	}

	
}
