/*package com.microservices.Database;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MyUserDetailsService implements UserDetailsService {

	//@Autowired
    private UserDetails User;

	@Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        //return new User("rec", "rec",
            //    new ArrayList<>());
		if("rec".equals(s)) {
			return new User("rec","rec",new ArrayList());
		}
		else if ("man".equals(s)) {
			return new User("man","man",new ArrayList());
		}
		else if ("own".equals(s)) {
			return new User("own","own",new ArrayList());
		}
		else {	
			throw new UsernameNotFoundException("not found"+s);
    }
          
}
	}*/