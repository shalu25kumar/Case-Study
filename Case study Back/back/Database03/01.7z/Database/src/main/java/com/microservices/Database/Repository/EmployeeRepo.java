package com.microservices.Database.Repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservices.Database.Model.Employee;



public interface EmployeeRepo extends MongoRepository<Employee,String>{

}