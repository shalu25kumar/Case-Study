package com.microservices.Database.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservices.Database.Model.Rooms;

public interface RoomRepo extends MongoRepository<Rooms, String>{

}
