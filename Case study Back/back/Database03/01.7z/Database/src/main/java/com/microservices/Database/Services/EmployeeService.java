package com.microservices.Database.Services;

import java.util.List;
import java.util.Optional;

import com.microservices.Database.Model.Employee;



public interface EmployeeService {
	public Employee addEmployee(Employee employee);
	
	public Optional<Employee> findEmployeeById(String Id);
	
	public String deleteEmployeeById(String Id);

	public List<Employee> findAllEmployee();
	
	public Employee saveOrUpdate(Employee employee);

}
