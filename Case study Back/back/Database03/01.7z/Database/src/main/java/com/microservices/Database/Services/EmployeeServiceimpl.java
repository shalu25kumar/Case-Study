package com.microservices.Database.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.microservices.Database.Model.Employee;
import com.microservices.Database.Repository.EmployeeRepo;



public class EmployeeServiceimpl implements EmployeeService{
	@Autowired
	EmployeeRepo employeeobj;

	@Override
	public Employee addEmployee(Employee employee) {
	return employeeobj.save(employee);
	}

	@Override
	public Optional<Employee> findEmployeeById(String Id) {
		
		return  employeeobj.findById(Id);
	}

	@Override
	public String deleteEmployeeById(String Id) {
		employeeobj.deleteById(Id);
		return ("Employee deleted");
	}
	@Override
	public List<Employee> findAllEmployee() {
		return employeeobj.findAll();
}

	@Override
	public Employee saveOrUpdate(Employee employee) {
		return employeeobj.save(employee);
		
	}
	
}
