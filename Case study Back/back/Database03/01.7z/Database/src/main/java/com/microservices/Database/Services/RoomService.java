package com.microservices.Database.Services;

import java.util.List;
import java.util.Optional;

import com.microservices.Database.Model.Rooms;



public interface RoomService {
	
	public Rooms addRoom(Rooms room);
	
	public Optional<Rooms> getRoomsById(String room_No);
	
	public String removeRoomsById(String room_No);

	public List<Rooms> findAll();

	public String saveOrUpdate(Rooms room);


}
