package com.microservices.Database.Services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.microservices.Database.Model.Rooms;
import com.microservices.Database.Repository.RoomRepo;



public class Roomserviceimpl implements RoomService{
	@Autowired
	RoomRepo roomRepo;

	@Override
	public Rooms addRoom(Rooms rooms) {
		return roomRepo.save(rooms);
	}
	
	@Override
	public Optional<Rooms> getRoomsById(String room_No) {
		return roomRepo.findById(room_No);
	}
	
	@Override
	public List<Rooms> findAll() {
		return roomRepo.findAll();
	}
	
	
	@Override
	public String removeRoomsById(String room_No) {
		roomRepo.deleteById(room_No);
		return ("Room deleted");
	
	}

	@Override
	public String saveOrUpdate(Rooms room) {
		roomRepo.save(room);
		return "room updated";
	}

}  



