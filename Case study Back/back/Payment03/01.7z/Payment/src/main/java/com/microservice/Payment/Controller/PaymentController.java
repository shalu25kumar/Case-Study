package com.microservice.Payment.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.Payment.Model.Payment;
import com.microservice.Payment.Service.Paymentserviceimpl;


@RestController
public class PaymentController {
	@Autowired
	private Paymentserviceimpl obj;

	@PostMapping(value="/addPayment")
	public Payment addPayment(@RequestBody Payment payment) {
		return obj.addPayment(payment);
	}

	@GetMapping("/findAllPayments")
	public List<Payment> getPayment() {
		return obj.findAll();
	}

	@GetMapping("/findAllPayment/{name}")
	public Optional<Payment> getRoom(@PathVariable String name) {
		return obj.findPayment(name);
	}

}
