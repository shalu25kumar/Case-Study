package com.microservice.Payment.Model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Generated;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString

@Document(collection = "payment")
public class Payment {
	
	
	//@Generated
	//public long txid;
	@Id
	public String name;
    public String room_No;
	public Date checkin;
	public Date checkout;
	public int noofdays;
	public int price;
	public int total;
	public String mode;
	public String status;

public Payment() {
}
@Override
public String toString() {
return "Payment [ name=" + name + ", room_No=" + room_No + ", checkin=" + checkin
		+ ", checkout=" + checkout + ", noofdays=" + noofdays + ", price=" + price + ", total=" + total
		+ ", mode=" + mode + ", status=" + status + "]";
	}
}