package com.microservice.Payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.microservice.Payment.Service.Paymentserviceimpl;


@SpringBootApplication
public class PaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentApplication.class, args);
	}
	@Bean
	public Paymentserviceimpl paymentserviceimpl() {
		return new Paymentserviceimpl();
	}
	

}
