package com.microservice.Payment.Service;

import java.util.List;
import java.util.Optional;

import com.microservice.Payment.Model.Payment;



public interface Paymentservice {
	
	public Payment addPayment(Payment payment);
	
	public List<Payment> findAll();
	
	public Optional<Payment>findPayment(String name);

}
