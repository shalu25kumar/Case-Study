package com.microservice.Payment.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.microservice.Payment.Model.Payment;
import com.microservice.Payment.Repository.PaymentRepo;

public class Paymentserviceimpl implements Paymentservice {
	@Autowired
	PaymentRepo paymentRepo;

	@Override
	public Payment addPayment(Payment payment) {
		// TODO Auto-generated method stub
		return paymentRepo.save(payment);
	}

	@Override
	public List<Payment> findAll() {
		return paymentRepo.findAll();
	}

	@Override
	public Optional<Payment> findPayment(String name) {
		 return paymentRepo.findById(name);
	}

}
