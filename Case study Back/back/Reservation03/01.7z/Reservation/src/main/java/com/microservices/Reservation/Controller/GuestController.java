package com.microservices.Reservation.Controller;

import java.util.List;

//import java.util.List;
//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;*/
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;


//import com.microservices.Reservation.MyUserDetailsService;
//import com.microservices.Reservation.filters.JwtRequestFilter;
//import com.microservices.Reservation.models.AuthenticationRequest;
//import com.microservices.Reservation.models.AuthenticationRequest;
//import com.microservices.Reservation.models.AuthenticationResponse;
import com.microservices.Reservation.models.Guest;
import com.microservices.Reservation.models.Inactive;
//import com.microservices.Reservation.models.Rooms;
import com.microservices.Reservation.service.GuestServiceimpl;
//import com.microservices.Reservation.util.JwtUtil;

@RestController
public class GuestController {
	//@Autowired
	//private AuthenticationManager authenticationManager;
	

	//@Autowired
	//private JwtUtil jwtTokenUtil;

	//@Autowired
	//private MyUserDetailsService userDetailsService;

	@Autowired
	private GuestServiceimpl obj;
	
	
	
	
	@PostMapping(value="/addGuest")
	public Guest addGuest(@RequestBody Guest guest) {
		return obj.addGuest(guest);
	}
	  

	
	@GetMapping(value="/findAllGuest")
	public List<Guest> findAllGuest() {
		return obj.findAllGuest();
	}
	
	

	
	@PutMapping("/updateguest")  
	public Guest update(@RequestBody Guest guest)   
	{  
	obj.saveOrUpdate(guest);  
	return guest;  
	} 
	
	@DeleteMapping("/deleteGuest/{name}")
	public String deleteGuest(@PathVariable String name) {
		obj.removeGuestByName(name);
		return "Guest deleted with name : " + name;
	}
	
	
	
	
	//rest template part
	@Bean
    public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	static final String OWNER_URL_MS="http://localhost:8082/";
	
	
		@RequestMapping("/findAllRooms")
		public String findAllRooms() {
			return restTemplate.exchange(OWNER_URL_MS+"findAllRooms",HttpMethod.GET,null,String.class).getBody();
	
	}}
	
	
	
	


	
	
/*	/// authentication part	
@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception {

		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
			);
		}
		catch (BadCredentialsException e) {
			throw new Exception("Incorrect username or password", e);
		}


		final UserDetails userDetails = userDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}

}

@EnableWebSecurity
class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private UserDetailsService myUserDetailsService;
	@Autowired
	private JwtRequestFilter jwtRequestFilter;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(myUserDetailsService);
	}

	@SuppressWarnings("deprecation")
	@Bean
	public PasswordEncoder passwordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}

	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.csrf().disable()
				.authorizeRequests().
				antMatchers("/login").permitAll().
						anyRequest().authenticated().
						and().
						
						// impl authoristion sample 2
				//antMatchers(HttpMethod.GET,"/findAllRooms/**").hasRole("user").
				
				/*antMatchers(HttpMethod.GET,"/findAllRooms/**").hasAuthority("man").
				antMatchers(HttpMethod.GET,"/findAllRooms/**").hasAuthority("own").
				
				antMatchers(HttpMethod.GET,"/findRoom/{room_No}/**").hasAuthority("man").
				antMatchers(HttpMethod.GET,"/findRoom/{room_No}/**").hasAuthority("rec").
				antMatchers(HttpMethod.GET,"/findRoom/{room_No}/**").hasAuthority("own").
				
				antMatchers(HttpMethod.PUT,"/updateroom/**").hasAuthority("rec").
				antMatchers(HttpMethod.PUT,"/updateroom/**").hasAuthority("man").
				antMatchers(HttpMethod.PUT,"/updateroom/**").hasAuthority("own").
				
				antMatchers(HttpMethod.POST,"/addGuest").hasAuthority("rec").anyRequest().authenticated().
				and().
				
				exceptionHandling().and().sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		httpSecurity.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

	}
	
}	


*/








