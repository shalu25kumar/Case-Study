package com.microservices.Reservation.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.Reservation.models.Inactive;
import com.microservices.Reservation.service.inserviceimpl;



@RestController
public class InactiveController {
	@Autowired
	private inserviceimpl obj;

	
	
	@PostMapping(value="/addinactive")
	  public Inactive addinactive(@RequestBody Inactive guest2) {
	  	return obj.addinactive(guest2);
	  }
	
	
	
	@GetMapping(value="/findinactive")
	public List<Inactive> findinactive() {
		return obj.findinactive();
	}
}
