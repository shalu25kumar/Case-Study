package com.microservices.Reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.microservices.Reservation.service.GuestServiceimpl;
import com.microservices.Reservation.service.inserviceimpl;


import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableEurekaClient
public class ReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationApplication.class, args);
	}
	

	@Bean
	public GuestServiceimpl guestserviceimpl() {
		return new GuestServiceimpl();
	}
 
	@Bean
	public inserviceimpl inserviceimpl() {
		return new inserviceimpl();
	}
	
}
