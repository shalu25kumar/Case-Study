package com.microservices.Reservation.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservices.Reservation.models.Inactive;



public interface InactiveRepo extends MongoRepository<Inactive,String>{

}
