package com.microservices.Reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.microservices.Reservation.models.Guest;
import com.microservices.Reservation.models.Inactive;
import com.microservices.Reservation.repository.GuestRepo;
import com.microservices.Reservation.repository.InactiveRepo;
import com.mongodb.internal.connection.Server;



public class GuestServiceimpl implements GuestService{
	@Autowired
	GuestRepo guestRepo;
	

	@Override
	public Guest addGuest(Guest guest) {
		return guestRepo.save(guest);
	} 

	@Override
	public List<Guest> findAllGuest() {
		return guestRepo.findAll();
	}
	
	@Override
	public String saveOrUpdate(Guest guest) {
		guestRepo.save(guest);
		return ("Guest updated");
	}
	@Override
	public String removeGuestByName(String name) {
		guestRepo.deleteById(name);
		return ("Guest deleted");
	}

	
}

