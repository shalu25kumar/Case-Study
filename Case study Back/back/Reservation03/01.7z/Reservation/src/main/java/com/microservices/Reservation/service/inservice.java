package com.microservices.Reservation.service;

import java.util.List;

import com.microservices.Reservation.models.Inactive;

public interface inservice {
	
	public Inactive addinactive(Inactive guest2);
	
	public List<Inactive> findinactive();


}
