package com.microservices.Reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.microservices.Reservation.models.Inactive;
import com.microservices.Reservation.repository.InactiveRepo;

public class inserviceimpl implements inservice {
	@Autowired
	InactiveRepo inrepo;
	
	@Override
	public Inactive addinactive(Inactive guest2) {
		return inrepo.save(guest2);
		
	}

	@Override
	public List<Inactive> findinactive() {
		return inrepo.findAll();
		
	}


}
