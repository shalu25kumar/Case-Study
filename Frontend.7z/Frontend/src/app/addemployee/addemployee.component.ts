import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServicesemployeeService } from '../servicesemployee.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  msg:string
  registerForm: FormGroup;
  noentry:string
  
  constructor(private formBuilder: FormBuilder ,private service:ServicesemployeeService, private router:Router) { }

  ngOnInit(): void {
  
  this.noentry = sessionStorage.getItem('userName');
  if (this.noentry == null) {
    this.router.navigate(['/mlogin']);
  }

  this.registerForm = this.formBuilder.group({
    id:['', [Validators.required, Validators.minLength(3)]],
    name:['', [Validators.required, Validators.minLength(5)]],
    age:['', [Validators.required, Validators.minLength(2)]],
    gender:['',[Validators.required]],
    designation:['', [Validators.required, Validators.minLength(5)]],
    phoneno:['', [Validators.required, Validators.minLength(5)]],
    address:['', [Validators.required, Validators.minLength(5)]],
    salary:['', [Validators.required]],
    d_o_j:['']
  });
}
SubmitForm(form: FormGroup) {
    
    this.service.RegisterEmployee(this.registerForm.value.id,this.registerForm.value.name,this.registerForm.value.age,this.registerForm.value.gender,this.registerForm.value.designation,this.registerForm.value.phoneno,this.registerForm.value.address,this.registerForm.value.salary,this.registerForm.value.d_o_j).subscribe(	res=>{
      if(res){alert("employee added succesfully")
      this.router.navigate(["/allemployee"])	}
      else
      alert("employee could not be added")
      },
      error=>{
      alert("some error occured")},
      ()=>console.log("form success")
      )
      }
      }
