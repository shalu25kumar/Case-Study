import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,  FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServicesguestService } from '../servicesguest.service';

@Component({
  selector: 'app-addrguest',
  templateUrl: './addrguest.component.html',
  styleUrls: ['./addrguest.component.css']
})
export class AddrguestComponent implements OnInit {
msg:string
registerForm: FormGroup;
noentry:string


  constructor(private formBuilder: FormBuilder ,private service:ServicesguestService, private router:Router) { }
 
  ngOnInit() {


    this.noentry = sessionStorage.getItem('userName');
    if (this.noentry == null) {
      this.router.navigate(['/login']);
    }
    this.registerForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(5)]],
      room_No: ['', [Validators.required, Validators.minLength(4)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      gender: ['',[Validators.required]],
      phone_No: ['', [Validators.required, Validators.minLength(10)]],
      email: ['', [Validators.required, Validators.minLength(5)]],
      No_of_guest: ['', [Validators.required, Validators.minLength(1)]],
      checkin: [''],
      checkout: [''],
      No_of_days: ['']
    });
  }


SubmitForm(form: FormGroup) {
    
  this.service.RegisterGuest(this.registerForm.value.name,this.registerForm.value.room_No,this.registerForm.value.address,this.registerForm.value.gender,this.registerForm.value.phone_No,this.registerForm.value.email,this.registerForm.value.No_of_guest,this.registerForm.value.checkin,this.registerForm.value.checkout,this.registerForm.value.No_of_days).subscribe(	res=>{
    if(res){alert("guest added succesfully")
    this.router.navigate(["/allguest"])	}
    else
    alert("guest could not be added")
    },
    error=>{
    alert("some error occured")},
    ()=>console.log("form success")
    )
    }
    }
