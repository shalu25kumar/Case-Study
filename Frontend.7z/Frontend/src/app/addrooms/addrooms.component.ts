import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-addrooms',
  templateUrl: './addrooms.component.html',
  styleUrls: ['./addrooms.component.css']
})
export class AddroomsComponent implements OnInit {
  msg:string
  registerForm: FormGroup;
  noentry:string
  
  constructor(private formBuilder: FormBuilder ,private service:ServicesService, private router:Router) { }

  ngOnInit(): void {
    this.noentry = sessionStorage.getItem('userName');
  if (this.noentry == null) {
    this.router.navigate(['/mlogin']);
  }  
  this.registerForm = this.formBuilder.group({
    room_No:['', [Validators.required, Validators.minLength(3)]],
    Type:['', [Validators.required, Validators.minLength(3)]],
    Status:['', [Validators.required, Validators.minLength(4)]],
    Price:['', [Validators.required, Validators.minLength(4)]],
    name:['']
  });
}
SubmitForm(form: FormGroup){
  this.service.RegisterRoom(this.registerForm.value.room_No,this.registerForm.value.Type,this.registerForm.value.Status,this.registerForm.value.Price,this.registerForm.value.name).subscribe(	res=>{
    if(res){alert("Room added succesfully")
    this.router.navigate(["/allemployee"])	}
    else
    alert("Room could not be added")
    },
    error=>{
    alert("some error occured")},
    ()=>console.log("form success")
    ) 
}

}
