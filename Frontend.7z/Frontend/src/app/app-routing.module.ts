import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuestComponent } from './guest/guest.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ManloginComponent } from './manlogin/manlogin.component';
import { RechomeComponent } from './rechome/rechome.component';
import { ManhomeComponent } from './manhome/manhome.component';
import { RoomsComponent } from './rooms/rooms.component';
import { EmployeeComponent } from './employee/employee.component';
import { AddrguestComponent } from './addrguest/addrguest.component';
import { UpdateroomComponent } from './updateroom/updateroom.component';
import { UpdaterguestComponent } from './updaterguest/updaterguest.component';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';
import { ReclayoutComponent } from './reclayout/reclayout.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { AddroomsComponent } from './addrooms/addrooms.component';
import { ManlayoutComponent } from './manlayout/manlayout.component';
import {InactiveComponent} from './inactive/inactive.component';

import {AuthGuardService} from './auth-guard.service'
import { MoveComponent } from './move/move.component';


const routes: Routes = [

  {path:'',component:HomeComponent},
  {path:'room' ,component: RoomsComponent},
  {path:'home' ,component: HomeComponent},
  {path:'login' ,component: LoginComponent},
  {path:'mlogin' ,component: ManloginComponent},
  {path:'rechome' ,component: RechomeComponent},
  {path:'manhome' ,component: ManhomeComponent,canActivate:[AuthGuardService]},
  {path:'allemployee' ,component: EmployeeComponent,canActivate:[AuthGuardService]},
  {path:'addrguest' ,component: AddrguestComponent},
  {path:'inactive' ,component: InactiveComponent},
  {path:'moveguest/:name/:room_No/:address/:gender/:phone_No/:email/:No_of_guest/:checkin/:checkout/:No_of_days' ,component: MoveComponent},
  
  {path:'addemployee' ,component: AddemployeeComponent,canActivate:[AuthGuardService]},
  {path:'addroom' ,component: AddroomsComponent,canActivate:[AuthGuardService]},
  {path:'allguest' ,component: GuestComponent},
  {path:'updateroom/:room_No/:Type/:Status/:Price/:name',component: UpdateroomComponent},
  {path:'updateguest/:name/:room_No/:address/:gender/:phone_No/:email/:No_of_guest/:checkin/:checkout/:No_of_days',component:UpdaterguestComponent},
  {path:'updateemployee/:id/:name/:age/:gender/:designation/:phoneno/:address/:salary/:d_o_j', component:UpdateemployeeComponent,canActivate:[AuthGuardService]},
  {path:'reclayout', component: ReclayoutComponent} ,
  {path:'manlayout', component: ManlayoutComponent} ,
 
 
 
 
  {path:"**",component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
