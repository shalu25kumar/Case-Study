import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RoomsComponent } from './rooms/rooms.component';
import { ServicesService } from './services.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManloginComponent } from './manlogin/manlogin.component';
import { RechomeComponent } from './rechome/rechome.component';
import { GuestComponent } from './guest/guest.component';
import { ServicesguestService } from './servicesguest.service';
import { ManhomeComponent } from './manhome/manhome.component';
import { EmployeeComponent } from './employee/employee.component';
import { ServicesemployeeService } from './servicesemployee.service';
import { AddrguestComponent } from './addrguest/addrguest.component';

import { IvyCarouselModule } from 'angular-responsive-carousel';
import { UpdateroomComponent } from './updateroom/updateroom.component';
import { UpdaterguestComponent } from './updaterguest/updaterguest.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';

import { ReclayoutComponent } from './reclayout/reclayout.component';
import { ManlayoutComponent } from './manlayout/manlayout.component';
import { AddroomsComponent } from './addrooms/addrooms.component';
import { InactiveComponent } from './inactive/inactive.component';
import { MoveComponent } from './move/move.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RoomsComponent,
    ManloginComponent,
    RechomeComponent,
    GuestComponent,
    ManhomeComponent,
    EmployeeComponent,
    AddrguestComponent,
    UpdateroomComponent,
    UpdaterguestComponent,
    AddemployeeComponent,
    UpdateemployeeComponent,
 
    ReclayoutComponent,
    ManlayoutComponent,
    AddroomsComponent,
    InactiveComponent,
    MoveComponent,
  
  ],
  imports: [
    BrowserModule,
    FormsModule,ReactiveFormsModule,
    AppRoutingModule, HttpClientModule,
    IvyCarouselModule
    
  ],
  providers: [ServicesService ,ServicesguestService ,ServicesemployeeService],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
