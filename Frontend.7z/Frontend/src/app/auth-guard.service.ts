import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {
noentry:string
  constructor(private _router:Router) { }

  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean
  {
      this.noentry=sessionStorage.getItem('userName')
    if ((this.noentry == 'rec')||(this.noentry==null)){
        alert("you are not allowed to view this page");
        return false;
      }
      return true;
    }

//   canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean
//   {
//       this.noentry=sessionStorage.getItem('userName')
//    if ((this.noentry == 'man')||(this.noentry==null)){
//        alert("you are not allowed to view this page");
//        return false;
//        }
//        return true;
//      }

  
}
