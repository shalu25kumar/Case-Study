import { Component, OnInit } from '@angular/core';
import { ServicesemployeeService } from '../servicesemployee.service';
import { Router } from '@angular/router';
import { Employee } from '../interfaces/Employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee:any[]
  filteredProducts:any[]
  name:string
  noentry:string
  searchByCategoryId:string="0"
  searchByname:string  
  
  constructor(private employeeService: ServicesemployeeService,private router:Router) { }

  ngOnInit(): void {
    {
      this.noentry = sessionStorage.getItem('userName');
      if ((this.noentry == 'rec')||(this.noentry==null)) {
        this.router.navigate(['/mlogin']);
      
      }
    }
    this.getEmployee();
  
  
  
  }
  getEmployee() {
    this.employeeService.getEmployee().subscribe(
     data => {this.employee = data
      this.filteredProducts=data}
      );
}
findEmployee(name: string) {
  if (this.searchByCategoryId == "0") {
    this.filteredProducts = this.employee;
  }
  else {
    this.filteredProducts = this.employee.filter(prod => prod.name.toString() == this.searchByCategoryId);
  }
  if (name != null || name == "") {
    this.searchByname = name;
    this.filteredProducts = this.filteredProducts.filter(prod => prod.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  
}
updateemployee(employee: Employee ){
  this.router.navigate(['updateemployee',employee.id,employee.name,employee.age,employee.gender,employee.designation,
  employee.phoneno,employee.address,employee.salary,employee.d_o_j]);
}


}
