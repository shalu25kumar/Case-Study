import { Component, OnInit } from '@angular/core';
import { ServicesguestService } from '../servicesguest.service';
import { Router } from '@angular/router';
import { Guest } from '../interfaces/Guest';


@Component({
  selector: 'app-guest',
  templateUrl: './guest.component.html',
  styleUrls: ['./guest.component.css']
})
export class GuestComponent implements OnInit {
  guest:any[]
  filteredProducts:any[]
  name:string
  searchByCategoryId:string='0'
  searchByname:string
  noentry:string
  reclayout:boolean
  manlayout:boolean

  constructor(private guestService: ServicesguestService,private router:Router) { }

  ngOnInit(): void
   {
    this.noentry = sessionStorage.getItem('userName');
    if (this.noentry == null) {
      this.router.navigate(['/login']);
    
    }
    else if(this.noentry == "rec"){
      this.reclayout=true
    }
    else{
      this.manlayout=true
    }
    

     this.getGuest();
     this.findGuest(this.name);
  }
getGuest() {
  this.guestService.getGuest().subscribe(
   data =>{this.guest = data,
    this.filteredProducts=data}
  );
}
findGuest(name: string) {
  if (this.searchByCategoryId == "0") {
    this.filteredProducts = this.guest;
  }
  else {
    this.filteredProducts = this.guest.filter(prod => prod.name.toString() == this.searchByCategoryId);
  }
  if (name != null || name == "") {
    this.searchByname = name;
    this.filteredProducts = this.filteredProducts.filter(prod => prod.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
  }
  
}
updateguest(guest: Guest){
  this.router.navigate(['updateguest',guest.name,guest.room_No,guest.address,guest.gender,guest.phone_No,guest.email,guest.No_of_guest,guest.checkin,guest.checkout,guest.No_of_days]);
}


payguest(){
  this.router.navigate(['payguest'])
}

moveguest(guest: Guest){
  this.router.navigate(['moveguest',guest.name,guest.room_No,guest.address,guest.gender,guest.phone_No,guest.email,guest.No_of_guest,guest.checkin,guest.checkout,guest.No_of_days]);

}
}

