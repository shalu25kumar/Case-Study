import { Component, OnInit } from '@angular/core';
import { ServicesguestService } from '../servicesguest.service';
import { Router } from '@angular/router';
import { Inactive } from '../interfaces/Inactive';


@Component({
  selector: 'app-inactive',
  templateUrl: './inactive.component.html',
  styleUrls: ['./inactive.component.css']
})
export class InactiveComponent implements OnInit {
  inactive:any[]
  filteredProducts:any[]
  name:string
  searchByCategoryId:string='0'
  searchByname:string
  noentry:string
  reclayout:boolean
  manlayout:boolean
  
  
  constructor(private guestService: ServicesguestService,private router:Router) { }

  ngOnInit(): void 
 
 
  {
    this.noentry = sessionStorage.getItem('userName');
    if (this.noentry == null) {
      this.router.navigate(['/login']);
    
    }
    else if(this.noentry == "rec"){
      this.reclayout=true
    }
    else{
      this.manlayout=true
    }


this.getinactive();
this.findGuest(this.name);
}
    
  
  
getinactive(){
this.guestService.getinactive().subscribe(
data =>{this.inactive = data,
this.filteredProducts=data}
);
  
}

findGuest(name: string){
if (this.searchByCategoryId == "0"){
this.filteredProducts = this.inactive;
}
else{
this.filteredProducts = this.inactive.filter(prod => prod.name.toString() == this.searchByCategoryId);
}
if (name != null || name == ""){
this.searchByname = name;
this.filteredProducts = this.filteredProducts.filter(prod => prod.name.toLowerCase().indexOf(name.toLowerCase()) >= 0);
}
}




}

