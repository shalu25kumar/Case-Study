export interface Employee{
    id:string;
	name:string;
    age:number;
	gender:CharacterData;
    designation:string;
    phoneno:string;
	address:string;
    salary:number;
    d_o_j:Date;
}