export interface Guest {
    name:string
	room_No:string
	address:string
	gender:CharacterData
    phone_No:number
	email:string
	No_of_guest:string
	checkin:Date
	checkout:Date
	No_of_days:string
}