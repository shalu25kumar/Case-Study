export interface Rooms {
    room_No:string
    Type:string
    Status:boolean
    Price:number
    name:string
}