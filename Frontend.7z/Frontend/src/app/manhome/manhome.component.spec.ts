import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManhomeComponent } from './manhome.component';

describe('ManhomeComponent', () => {
  let component: ManhomeComponent;
  let fixture: ComponentFixture<ManhomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManhomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
