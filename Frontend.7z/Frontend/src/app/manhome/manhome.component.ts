import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manhome',
  templateUrl: './manhome.component.html',
  styleUrls: ['./manhome.component.css']
})
export class ManhomeComponent implements OnInit {
  noentry:string
  constructor(private router:Router) { }

  logout(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');
  }

  ngOnInit(): void {
    this.noentry = sessionStorage.getItem('userName');
    if ((this.noentry == 'rec')||(this.noentry==null)) {
      this.router.navigate(['/mlogin']);
  }
  }

}
