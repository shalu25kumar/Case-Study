import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManlayoutComponent } from './manlayout.component';

describe('ManlayoutComponent', () => {
  let component: ManlayoutComponent;
  let fixture: ComponentFixture<ManlayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManlayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManlayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
