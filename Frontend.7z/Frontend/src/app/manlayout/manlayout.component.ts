import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manlayout',
  templateUrl: './manlayout.component.html',
  styleUrls: ['./manlayout.component.css']
})
export class ManlayoutComponent implements OnInit {

  constructor() { }
  logout(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');
  }

  ngOnInit(): void {
  }

}
