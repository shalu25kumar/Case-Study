import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManloginComponent } from './manlogin.component';

describe('ManloginComponent', () => {
  let component: ManloginComponent;
  let fixture: ComponentFixture<ManloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
