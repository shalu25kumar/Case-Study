import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-manlogin',
  templateUrl: './manlogin.component.html',
  styleUrls: ['./manlogin.component.css']
})
export class ManloginComponent implements OnInit {


man:any[]
 msg:string;
 showDiv:boolean=false;
 status:string="manager";
  
 
 
 constructor(private router:Router) { }
  submitLoginForm(form: NgForm) {

    for( var value of this.man)
    {
      this.showDiv=(form.value.userid==value.userid)&&(form.value.password==value.password)
    
      if( this.showDiv)
      {
     
        console.log("Success");
          this.msg="success";
          sessionStorage.setItem('userName',form.value.userid)
          sessionStorage.setItem('userRole',this.status)
          this.router.navigate(["/manhome"]);
      }
    else 
    {
      console.log("failed");
      this.msg="enter valid cred";
      
    }

  }

}

  ngOnInit(): void {
    this.man=[

      { "userid": "man", "password": "123"}]
    
  }

}
