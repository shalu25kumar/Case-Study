import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RechomeComponent } from './rechome.component';

describe('RechomeComponent', () => {
  let component: RechomeComponent;
  let fixture: ComponentFixture<RechomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RechomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RechomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
