import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Rooms } from '../interfaces/Rooms';

@Component({
  selector: 'app-rechome',
  templateUrl: './rechome.component.html',
  styleUrls: ['./rechome.component.css']
})
export class RechomeComponent implements OnInit {
noentry:string
  constructor(private router:Router) { }
  logout(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');

  }
  updateRoom(rooms: Rooms) {
    this.router.navigate(['/updateroom', rooms.room_No, rooms.Type, rooms.Status, rooms.Price,rooms.name]);
  }
  ngOnInit(): void {
    this.noentry = sessionStorage.getItem('userName');
    if ((this.noentry == 'man')||(this.noentry==null)) {
      this.router.navigate(['/login']);
  }
  }
}
