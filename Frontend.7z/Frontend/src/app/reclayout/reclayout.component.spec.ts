import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReclayoutComponent } from './reclayout.component';

describe('ReclayoutComponent', () => {
  let component: ReclayoutComponent;
  let fixture: ComponentFixture<ReclayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReclayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReclayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
