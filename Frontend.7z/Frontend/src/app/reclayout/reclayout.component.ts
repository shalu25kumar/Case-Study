import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Rooms } from '../interfaces/Rooms';
@Component({
  selector: 'app-reclayout',
  templateUrl: './reclayout.component.html',
  styleUrls: ['./reclayout.component.css']
})
export class ReclayoutComponent implements OnInit {

  constructor(private router:Router) { }
  logout(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');
  }
  updateRoom(rooms: Rooms) {
    this.router.navigate(['/updateroom', rooms.room_No, rooms.Type, rooms.Status, rooms.Price,rooms.name]);
  }
  ngOnInit(): void {
  }

}