import { Component, OnInit } from '@angular/core';
import { ServicesService } from '../services.service';
import { Router } from '@angular/router';
import { Rooms } from '../interfaces/Rooms';


@Component({
  selector: 'app-rooms',
  templateUrl: './rooms.component.html',
  styleUrls: ['./rooms.component.css']
})
export class RoomsComponent implements OnInit {
  rooms:any[]
  filteredProducts:any[]
  roomno:string
  searchByCategoryId:string="0"
  categories:any[]
  searchByRoomNo:string
  searchByProductName:string
  noentry:string
  reclayout:boolean
  manlayout:boolean
  
  
  constructor(private roomService: ServicesService,private router:Router){}
 

  ngOnInit(): void 
  {
    this.noentry = sessionStorage.getItem('userName');
    if (this.noentry == null) {
      this.router.navigate(['/login']);
    
    }
    else if(this.noentry == "rec"){
      this.reclayout=true
    }
    else{
      this.manlayout=true
    }
    
    
    this.getRooms();
    this.findRoom(this.roomno);
    this.categories=[{"type":"1","categoryId":"true"},{"type":"2","categoryId":"false"}]
   
}
 getRooms() {
  this.roomService.getRooms().subscribe(
   data =>{this.rooms = data,
   this.filteredProducts=data}
  );
}


findRoom(room_No: string) {

  if (this.searchByCategoryId == "0") {
    this.filteredProducts = this.rooms;
  }
  else {
    this.filteredProducts = this.rooms.filter(prod => prod.room_No.toString() == this.searchByCategoryId);
  }
  if (room_No != null || room_No == "") {
    this.searchByRoomNo = room_No;
    this.filteredProducts = this.filteredProducts.filter(prod => prod.room_No.toLowerCase().indexOf(room_No.toLowerCase()) >= 0);
  }

}


searchProductByCategory(categoryId: string) {
  if (this.searchByProductName != null || this.searchByProductName == "") {
    this.filteredProducts = this.rooms.filter(prod => prod.Status.toLowerCase().indexOf(this.searchByProductName.toLowerCase()) >= 0);
  }
  else {
    this.filteredProducts = this.rooms;
  }
  this.searchByCategoryId = categoryId;
  if (this.searchByCategoryId == "0") {
    this.filteredProducts = this.rooms;
  }
  else {
    this.filteredProducts = this.filteredProducts.filter(prod => prod.Status.toString() == this.searchByCategoryId);
  }
}

uprooms(rooms: Rooms)
  {
    this.router.navigate(['updateroom',rooms.room_No,rooms.Type,rooms.Status,rooms.Price,rooms.name]);
  }
}
