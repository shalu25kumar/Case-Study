import { Injectable } from '@angular/core';
import { HttpClient,HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Rooms } from 'src/app/interfaces/Rooms';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {
 
  
 
  constructor(private http: HttpClient) { }
  getRooms(): Observable<Rooms[]> {
    let tempVar = this.http.get<Rooms[]>('http://localhost:8082/findAllRooms');
    return tempVar;
  }

  findRoom(room_No:string):Observable<Rooms[]> {
    let param = "?room_No=" + room_No;
    let tempVar = this.http.get<Rooms[]>('http://localhost:8082//findAllRooms/{room_No}'+param);
    return tempVar;
  }


  updateRooms(room_No:string, 
  Type:string,
  Status:boolean,
  Price:number,
  name:string): Observable<Rooms> {
  var roomObj:Rooms ;
    roomObj = { room_No: room_No, Type: Type, Status: Status,Price:Price,name:name};
    return this.http.put<Rooms>('http://localhost:8082/updateroom',roomObj);
  }

  RegisterRoom(room_No:string,Type:string,Status:boolean,Price:number,name:string):Observable<boolean>{
    var obj : Rooms
    obj={
      room_No:room_No,
      Type:Type,
      Status:Status,
      Price:Price,
      name:name
    
    }
    console.log(obj);
    var temp =this.http.post<boolean>('http://localhost:8082/addRoom',obj)
    return temp;
  }
}
