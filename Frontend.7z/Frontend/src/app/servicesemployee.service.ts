import { Injectable } from '@angular/core';
import { HttpClient,HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from 'src/app/interfaces/Employee';

@Injectable({
  providedIn: 'root'
})
export class ServicesemployeeService{
  [x: string]: any;

 
  constructor(private http: HttpClient) { }
  getEmployee(): Observable<Employee[]> {
    let tempVar = this.http.get<Employee[]>('http://localhost:8082/findAllEmployee');
    return tempVar;
  }
  
  RegisterEmployee(id:string,name:string,age:number,
  gender:CharacterData,designation:string,phoneno:string,
  address:string,salary:number,d_o_j:Date):Observable<boolean>{
  var obj :Employee
  obj={
    id:id,
    name:name,
    age:age,
    gender: gender,
    designation:designation,
    phoneno:phoneno,
    address:address,
    salary:salary,
    d_o_j:d_o_j
  }
  console.log(obj);
  var temp =this.http.post<boolean>('http://localhost:8082/addEmployee',obj)
  return temp;
}

updateemployee(id:string,name:string,age:number,gender:CharacterData,
  designation:string,phoneno:string,address:string,
  salary:number,d_o_j:Date):Observable<Employee>{
      
    var Obj:Employee ;
      Obj = {id:id,name:name,age:age,gender: gender,designation:designation,
        phoneno:phoneno,address:address,salary:salary,d_o_j:d_o_j};
      return this.http.put<Employee>('http://localhost:8082/updateEmployee',Obj);
      }

}