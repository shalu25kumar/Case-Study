import { Injectable } from '@angular/core';
import { HttpClient,HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Guest } from 'src/app/interfaces/Guest';
import { Inactive } from 'src/app/interfaces/Inactive';


@Injectable({
  providedIn: 'root'
})
export class ServicesguestService{
  [x: string]: any;

 
  constructor(private http: HttpClient) { }
  getGuest(): Observable<Guest[]> {
    let tempVar = this.http.get<Guest[]>('http://localhost:8081/findAllGuest');
    return tempVar;
  }

  RegisterGuest( name:string, room_No:string, address:string, gender:CharacterData, phone_No:number, email:string, No_of_guest:string, checkin:Date, checkout:Date, No_of_days:string):Observable<boolean>{
    var obj :Guest
    obj= {
      name:name,
      room_No:room_No,
      address:address,
      gender:gender,
      phone_No:phone_No,
      email:email,
      No_of_guest:No_of_guest,
      checkin:checkin,
      checkout:checkout,
      No_of_days:No_of_days
    }
console.log(obj);
var temp =this.http.post<boolean>('http://localhost:8081/addGuest',obj)
return temp;
    }



    updateGuest(name:string,
      room_No:string,
      address:string,
      gender:CharacterData,
      phone_No:number,
      email:string,
      No_of_guest:string,
      checkin:Date,
      checkout:Date,
      No_of_days:string,
      ): Observable<Guest> {
      var Obj:Guest ;
      Obj = {name:name,room_No:room_No,address:address,gender:gender,phone_No:phone_No,email:email,No_of_guest:No_of_guest,checkin:checkin,checkout:checkout,
      No_of_days:No_of_days};
      return this.http.put<Guest>('http://localhost:8081/updateguest',Obj);
      }

payguest():Observable<true>{
  return this.http.get<true>('http://localhost:8089/payments');
}







// in active guest 
getinactive(): Observable<Inactive[]> {
  let tempVar = this.http.get<Inactive[]>('http://localhost:8081/findinactive');
  return tempVar;
}

Registerinactive( name:string, room_No:string, address:string, gender:CharacterData, 
  phone_No:number, email:string, No_of_guest:string, checkin:Date, checkout:Date, 
  No_of_days:string):Observable<boolean>{
  var obj :Guest
  obj= {
    name:name,
    room_No:room_No,
    address:address,
    gender:gender,
    phone_No:phone_No,
    email:email,
    No_of_guest:No_of_guest,
    checkin:checkin,
    checkout:checkout,
    No_of_days:No_of_days
  }
console.log(obj);
var temp =this.http.post<boolean>('http://localhost:8081/addinactive',obj)
return temp;
}




MoveGuest( name:string, room_No:string, address:string, gender:CharacterData, phone_No:number, email:string, No_of_guest:string, checkin:Date, checkout:Date, No_of_days:string):Observable<boolean>{
  var obj :Guest
  obj= {
    name:name,
    room_No:room_No,
    address:address,
    gender:gender,
    phone_No:phone_No,
    email:email,
    No_of_guest:No_of_guest,
    checkin:checkin,
    checkout:checkout,
    No_of_days:No_of_days
  }
console.log(obj);
var temp =this.http.post<boolean>('http://localhost:8081/addinactive',obj)
return temp;
  }

  
DeleteGuest( name:string):Observable<boolean>{
  let param = "?name=" + name;
  console.log(name);
  var temp =this.http.delete<boolean>('http://localhost:8081/deleteGuest/{name}'+param);
  return temp;
    }


    

}
