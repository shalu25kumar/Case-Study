import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,  FormControl, Validators,FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesemployeeService } from '../servicesemployee.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {
  id:string;
	name:string;
  age:number;
	gender:CharacterData;
  designation:string;
  phoneno:string;
	address:string;
  salary:number;
  d_o_j:Date;
  
  
  
  constructor(private formBuilder: FormBuilder, private route:ActivatedRoute,private service:ServicesemployeeService,private router:Router) { }

  ngOnInit(): void {
  this.id= this.route.snapshot.params['id'];
	this.name= this.route.snapshot.params['name'];
  this.age= this.route.snapshot.params['age'];
	this.gender= this.route.snapshot.params['gender'];
  this.designation= this.route.snapshot.params['designation'];
  this.phoneno= this.route.snapshot.params['phoneno'];
	this.address= this.route.snapshot.params['address'];
  this.salary= this.route.snapshot.params['salary'];
  this.d_o_j= this.route.snapshot.params['d_o_j'];

  }
  SubmitForm(form: FormGroup) {
    
    this.service.updateemployee(this.id,this.name,this.age,this.gender,this.designation,this.phoneno,this.address,this.salary,this.d_o_j).subscribe(	
      res=>{ 
      console.log(this.id)
      console.log(this.name)
      if(res)
      {
        alert("employee updated succesfully")
        this.router.navigate(['allemployee'])
        }
      else
      alert("employee not updated")
      },
      error=>{
      alert("some error occured")},
      ()=>console.log(" success")
      )
      }
}

