import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdaterguestComponent } from './updaterguest.component';

describe('UpdaterguestComponent', () => {
  let component: UpdaterguestComponent;
  let fixture: ComponentFixture<UpdaterguestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdaterguestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdaterguestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
