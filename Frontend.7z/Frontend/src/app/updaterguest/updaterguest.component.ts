import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,  FormControl, Validators,FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesguestService } from '../servicesguest.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-updaterguest',
  templateUrl: './updaterguest.component.html',
  styleUrls: ['./updaterguest.component.css']
})
export class UpdaterguestComponent implements OnInit {
  name:string
	room_No:string
	address:string
	gender:CharacterData
  phone_No:number
	email:string
	No_of_guest:string
	checkin:Date
	checkout:Date
	No_of_days:string
  
  
  constructor(private formBuilder: FormBuilder, private route:ActivatedRoute,private service:ServicesguestService,private router:Router) { }
 
  ngOnInit(): void {
    this.name = this.route.snapshot.params['name'];
    this.room_No = this.route.snapshot.params['room_No'];
    this.address = this.route.snapshot.params['address'];
    this.gender = this.route.snapshot.params['gender'];
    this.phone_No = this.route.snapshot.params['phone_No'];
    this.email = this.route.snapshot.params['email'];
    this.No_of_guest = this.route.snapshot.params['No_of_guest'];
    this.checkin = this.route.snapshot.params['checkin'];
    this.checkout = this.route.snapshot.params['checkout'];
    this.No_of_days = this.route.snapshot.params['No_of_days'];

  }
  SubmitForm(form: FormGroup) {
    
    this.service.updateGuest(this.name,this.room_No,this.address,this.gender,this.phone_No,this.email,this.No_of_guest,this.checkin,this.checkout,this.No_of_days).subscribe(	
      res=>{ 
      console.log(this.name)
      console.log(this.checkout)
      if(res)
      {
        alert("guest updated succesfully")
        this.router.navigate(['allguest'])
        }
      else
      alert("guest not updated")
      },
      error=>{
      alert("some error occured")},
      ()=>console.log(" success")
      )
      }
}
