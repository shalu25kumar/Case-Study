import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,  FormControl, Validators,FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesService } from '../services.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-updateroom',
  templateUrl: './updateroom.component.html',
  styleUrls: ['./updateroom.component.css']
})
export class UpdateroomComponent implements OnInit {
    room_No:string
    Type:string
    Status:boolean
    Price:number
    name:string
   
  

  constructor(private route:ActivatedRoute,private service:ServicesService,private router:Router) { }

  ngOnInit(): void {
    this.room_No = this.route.snapshot.params['room_No'];
    this.Type = this.route.snapshot.params['Type'];
    this.Status = this.route.snapshot.params['Status'];
    this.Price = this.route.snapshot.params['Price'];
    this.name = this.route.snapshot.params['name'];

 
  }
  
SubmitForm(form: FormGroup) {
    
  this.service.updateRooms(this.room_No,this.Type,this.Status,this.Price,this.name).subscribe(	
    res=>{ 
    console.log(this.room_No)
    console.log(this.name)
    if(res)
    {
      alert("room updated succesfully")
      this.router.navigate(['room'])
    	}
    else
    alert("room not updated")
    },
    error=>{
    alert("some error occured")},
    ()=>console.log(" success")
    )
    }

}
